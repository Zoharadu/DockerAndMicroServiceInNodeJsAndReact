
export const config = {
    ADRESS1:"http://localhost:8000/api/group",
    ADRESS2:"http://localhost:8000/api/person",
    ADRESS3:"http://localhost:8000/api/compositor"
}
